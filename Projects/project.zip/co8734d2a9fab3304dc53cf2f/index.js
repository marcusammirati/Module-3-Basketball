
let homeEl = document.getElementById("home-el")
let countHome = 0


function oneHome() {
    countHome += 1
    homeEl.innerText = countHome
}

function twoHome() {
    countHome += 2
    homeEl.innerText = countHome
    
    
}

function threeHome() {
    
    countHome += 3
    homeEl.innerText = countHome
    
}


let awayEl = document.getElementById("away-el")
let countAway = 0


function oneAway() {
    countAway += 1
    awayEl.innerText = countAway
    
    
}


function twoAway() {
    
    countAway += 2
    awayEl.innerText = countAway
    
}


function threeAway() {
    
    countAway += 3
    awayEl.innerText = countAway
    
}